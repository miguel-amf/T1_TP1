var class_custo =
[
    [ "Custo", "class_custo.html#a23e5f579d7d4b049bece9f3bf2b3b2ff", null ],
    [ "getCusto", "class_custo.html#a4675bf33c85211fb3bc700984e97f839", null ],
    [ "setCusto", "class_custo.html#af12346e4019fe35e3ad7b7611815497e", null ]
];