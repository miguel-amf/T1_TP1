var class_data =
[
    [ "Data", "class_data.html#af11f741cb7f587e2e495452a8905a22a", null ],
    [ "getData", "class_data.html#afc7b15a5e81334858e48709b2f45cdc3", null ],
    [ "setData", "class_data.html#a03663d77e3d9a619da60d2a3e8289387", null ]
];