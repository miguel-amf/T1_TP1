var class_email =
[
    [ "Email", "class_email.html#a2cfcfea1e55511208e7858c33f48ad9d", null ],
    [ "getEmail", "class_email.html#aa9a0e1a66b4efde65cf017bdd1c6c625", null ],
    [ "setEmail", "class_email.html#a47fc9d4d76a2e2a7bc502f16c1d034be", null ]
];