var class_estado_projeto =
[
    [ "EstadoProjeto", "class_estado_projeto.html#aa90f295ccc336e23d90f6d2558c2debb", null ],
    [ "getEstado", "class_estado_projeto.html#ac869125516a74b40b085392aab817147", null ],
    [ "setEstado", "class_estado_projeto.html#ab8678ea7ca0a8b6c40f10cd69642fff0", null ]
];