var class_fase_projeto =
[
    [ "FaseProjeto", "class_fase_projeto.html#a8ba8ac85bfdaca064dc03eabf034616b", null ],
    [ "getFase", "class_fase_projeto.html#af0cf25acf45544aec08d4b3c29623d4d", null ],
    [ "setFase", "class_fase_projeto.html#a396f8ed0da0ce0c567bdd3e3b3ceca86", null ]
];