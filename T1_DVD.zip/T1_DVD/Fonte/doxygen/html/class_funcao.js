var class_funcao =
[
    [ "Funcao", "class_funcao.html#a5591fbf42b8eca3c6c58233221896082", null ],
    [ "getFuncao", "class_funcao.html#ad6ecc462b997bc713436045762c6c7da", null ],
    [ "setFuncao", "class_funcao.html#a530bf1a4e7a4a868c586fe5385d54c26", null ]
];