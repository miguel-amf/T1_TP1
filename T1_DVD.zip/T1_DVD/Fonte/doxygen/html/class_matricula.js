var class_matricula =
[
    [ "Matricula", "class_matricula.html#a1bce1b1921c714f243574f671f46be55", null ],
    [ "getMatricula", "class_matricula.html#a193901a3c97e22bd0a9dde34ecc28eab", null ],
    [ "setMatricula", "class_matricula.html#af5fa061fc9bc4adeee8c0d607de9aa87", null ]
];