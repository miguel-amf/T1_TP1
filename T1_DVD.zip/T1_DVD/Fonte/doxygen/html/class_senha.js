var class_senha =
[
    [ "Senha", "class_senha.html#ade5ef5c7f37a1dd7a3bea575fb745a46", null ],
    [ "getSenha", "class_senha.html#a1cc904431d0a8287d0b22dee3e9d34ae", null ],
    [ "setSenha", "class_senha.html#a735e4bf5f65cc8d28daa7dbf202fd999", null ]
];