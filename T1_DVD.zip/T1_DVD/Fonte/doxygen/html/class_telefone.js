var class_telefone =
[
    [ "Telefone", "class_telefone.html#a9611a4bc0ee29b63e8246c1d80cb30f3", null ],
    [ "getNumero", "class_telefone.html#a6f1a23d8ab8c9e106f433765f03f5816", null ],
    [ "setNumero", "class_telefone.html#a10d069984be17675cc1540eab281750e", null ]
];