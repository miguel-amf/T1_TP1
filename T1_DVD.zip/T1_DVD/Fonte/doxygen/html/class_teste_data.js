var class_teste_data =
[
    [ "TesteData", "class_teste_data.html#aebb0576887de39670fb0cabc813efb98", null ],
    [ "run", "class_teste_data.html#a75ed74a12070f0a62eeaa4bb365cef97", null ],
    [ "setUp", "class_teste_data.html#a92f47fdac97015e880fff6fc7c0bb6cd", null ],
    [ "tearDown", "class_teste_data.html#a3b20b514c19c6972fcfca288ac039098", null ]
];