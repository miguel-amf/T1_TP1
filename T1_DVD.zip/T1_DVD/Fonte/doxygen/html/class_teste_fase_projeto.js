var class_teste_fase_projeto =
[
    [ "TesteFaseProjeto", "class_teste_fase_projeto.html#aa9a31cc8b2e32fd67047fb2ae27569c7", null ],
    [ "run", "class_teste_fase_projeto.html#a046b7ae2f488501a2ac6cea80453bf47", null ],
    [ "setUp", "class_teste_fase_projeto.html#ad9eb5a022d69b63fbdb342b4b7c6d15e", null ],
    [ "tearDown", "class_teste_fase_projeto.html#ac714ba5712a33cfc305faba36db1e0e4", null ]
];