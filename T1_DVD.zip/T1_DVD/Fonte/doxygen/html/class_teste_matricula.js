var class_teste_matricula =
[
    [ "TesteMatricula", "class_teste_matricula.html#a154de8ab96d16f84af32ffde4ea88df7", null ],
    [ "run", "class_teste_matricula.html#a254fdd7471848f7fbf7f78d56eeb7ef5", null ],
    [ "setUp", "class_teste_matricula.html#a9c2e291b5057b99e5793291be1a1706c", null ],
    [ "tearDown", "class_teste_matricula.html#adc4fd3edf0cdf002d17538cfd7a88526", null ]
];