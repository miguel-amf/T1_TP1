var class_teste_nome =
[
    [ "TesteNome", "class_teste_nome.html#a89462b0b8a3fe68493b37bc1737b484b", null ],
    [ "run", "class_teste_nome.html#a0fe4769e96c16ead9f04e99c3f53c0c4", null ],
    [ "setUp", "class_teste_nome.html#ab058167e207d9976bc8c48a2eb17830d", null ],
    [ "tearDown", "class_teste_nome.html#aa0adaef6bb42a1f0c29c1b3e64a42d7b", null ]
];