var class_teste_telefone =
[
    [ "TesteTelefone", "class_teste_telefone.html#ad932414f5f8fca8cda8c7065fda478b6", null ],
    [ "run", "class_teste_telefone.html#ad4b5c5e9b6291ab9758ef95bfa90452e", null ],
    [ "setUp", "class_teste_telefone.html#a03de3e0df3d55d6735f79bff7f0748d3", null ],
    [ "tearDown", "class_teste_telefone.html#a88cfd55b3d278a7075a2dd03ec9ce227", null ]
];