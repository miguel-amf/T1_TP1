var searchData=
[
  ['data',['Data',['../class_data.html#af11f741cb7f587e2e495452a8905a22a',1,'Data']]]
];
